function tsaps(analysis_type,per_nf)

%% TimeSAPS - Time Series Analysis for Persistent Scatterers
%
% A tool for modeling the PS' time series, using the Hauss-Markov least
% squares method and the Lomb Scargle Periodogram
%
%   TimeSAPS reference: https://github.com/eugeniagiorgini/TimeSAPS
%
%   StaMPS reference: https://homepages.see.leeds.ac.uk/~earahoo/stamps/
%   
%   Train reference: https://github.com/dbekaert/TRAIN
%
% Hot to use: 
%
%   A. KNOWN PERIODS
%       tsaps('kp',[vector of known periods])
%       ex. tsaps('kp',[1,2,0.5])
%       For seraching the presence of specific sinuoids characterized by
%       specifi periods in teh dataset
%
%   B. UNKNOWN FREQUENCIES
%       tsaps('uf',n)
%       ex. tsaps('uf',3)
%       n: number of sinusoids used for modelling the ts
%       For modeling the time series with a specific number of sinusoids,
%       identified using the Lomb-Scargle periodogram
%       NOTE: Only the most statistical frequency will be used, and in some
%       cases the number of them is less than the n isert by the user.
%
% After running step B and C a new matlab variable will be saved and a .csv
% data.
%       
% <Eugenia.giorgini@unibo.it>


%% Check input argument
if nargin<2
    error('Error: Insert the right number of inputs.')
elseif nargin>2
    error('Error: Insert the right number of inputs.')
else
    switch analysis_type
        case{'kp'}
            at='kp';
            if per_nf==0
                kp=0;
            else
                kp=per_nf;
                for i=1:length(kp)
                    if(kp(i))<0
                        error('Error: The period must be positive!')
                    end
                end
            end
        case{'uf'}
            at='uf';
            if per_nf<=0
                error('Error: The number of frequencies must be positive!')
            else
                nf=per_nf;
            end
        otherwise
            error('Error: Insert the right input!')
    end
end
    
    
    
%% Load data
prompt = "ps_plot_ts StaMPS file: ";
path_ts = input(prompt,"s")

prompt = "ps_plot StaMPS file: ";
path_ps_plot = input(prompt,"s")

load(path_ts)
load(path_ps_plot)

% load('/media/Dati/Poluzzi/SAR/TimeSAPS/INSAR_20180313_LITTLE/ps_plot_ts_v-d.mat')
% load('/media/Dati/Poluzzi/SAR/TimeSAPS/INSAR_20180313_LITTLE/ps_plot_v-d.mat')

var_check=["lonlat" "ph_disp" "ph_mm" "ref_ps"];
for i=1:length(var_check)
    if exist(var_check(i),'var')
    else
        error('Error: Some variables are missing! Load the StaMPS output. \n Variables needed: lonlat, ph_disp, ph_mm, ref_ps,day')
    end
end

data=decyear(datevec(day));   
n_ps=length(ph_mm(:,1));
%% TS Analysis
switch (at)
    
    %% Known Periods Analysis
    case {'kp'}
        clear models regression_lines sinusoids model_parameters
        
        fprintf('* Known Periods Analysis *\n')
        fprintf('Known Periods Analysis: Start!\n')
        %Check on the known periods
        fprintf(strcat(num2str(n_ps), ' PS loaded\n'))
        %Regression line only
        tic
        if kp==0
            
            sinusoids=zeros(1,length(data));
            fprintf('Known Periods Analysis: Estimating the Regression Line\n')
            
            for i=1:n_ps
                [m(i,1),q(i,1),~]=tsaps_detrend(data,ph_mm(i,:)',data(1));
                
                [regression_lines(i,:),models(i,:)] =tsaps_signal_recostruction_nofreq(data,m(i),q(i));
                
                [stdev(i,1),diff(i,:)] = tsaps_signal_std(ph_mm(i,:),models(i,:));
                
                snr_ps(i,1)=snr(ph_mm(i,:),diff(i,:));

                if mod(i,1000)==0
                    fprintf(strcat(num2str(i),' PS processed\n'))
                end

            end
            toc
            fprintf(strcat(num2str(i), ' PS processed\n'))
            model_parameters=[ref_ps lonlat m q stdev snr_ps];
        
        %Known Periods    
        else
            [kf,kf_n] = tsaps_freq_conversion(kp);
            
            fprintf('Known Periods Analysis: Modeling the PS\n')
            tic
            for i=1:length(ph_mm)
                [m(i,1),q(i,1),U1(i,:),U2(i,:)] =tsaps_freq_known(data,ph_mm(i,:)',data(1),kf_n,kf);
                
                [A(i,:),phi(i,:)]=tsaps_amplitude_phase(U1(i,:),U2(i,:));
                
                [sinusoids(i,:),regression_lines(i,:),models(i,:)] = tsaps_signal_recostruction(data,m(i),q(i),kf_n,kf,U1(i,:),U2(i,:));
            
                [stdev(i,1),diff(i,:)] =tsaps_signal_std(ph_mm(i,:),models(i,:));
                
                snr_ps(i,1)=snr(ph_mm(i,:),diff(i,:));
                
                if mod(i,1000)==0
                    fprintf(strcat(num2str(i),' PS processed\n'))
                end
                
            end
            toc
            model_parameters=[ref_ps lonlat m q stdev snr_ps];
            
            for i=1:kf_n
                pp=3*i-2+7;
                qq=3*i-1+7;
                rr=3*i+7;
                model_parameters(:,pp)=kf(i);
                model_parameters(:,qq)=A(i);
                model_parameters(:,rr)=phi(i);
            end
            
        end
        
        fprintf('Known Periods Analysis: Saving Models\n')
        
        save('tsaps_known_periods.mat','models','regression_lines','sinusoids','data','model_parameters','ph_mm');
        writematrix('model_parameters','tsaps_known_periods_model_parameters.csv');
        writematrix('model_parameters','tsaps_known_periods_models.csv');
    
        fprintf('Known Periods Analysis: Finish!')

    case {'uf'}
        clear models regression_lines sinusoids model_parameters
        
        fprintf('* Unknown Frequencies Analysis *\n')
        fprintf('Unknown Frequencies Analysis: Start!\n')
        fprintf(strcat(num2str(n_ps), ' PS loaded\n'))
        
        tic
        for i=1:n_ps
        
            [m_det(i,:),q_det(i,:),serie_det(i,:)]=tsaps_detrend(data,ph_mm(i,:)',data(1));
            
            [m(i,1),q(i,1),U1(i,:),U2(i,:),f(i,:),sinusoids(i,:),regression_lines(i,:),models(i,:)] = tsaps_find_signals(nf,serie_det(i,:),ph_mm(i,:),data);
            
            if (m(i,1))==0
                sinusoids(i,:)=zeros(1,length(data));
                [regression_lines(i,:),models(i,:)] = tsaps_signal_recostruction_nofreq(data,m_det(i),q_det(i));
                m(i,1)=m_det(i,1);
                q(i,1)=q_det(i,1);
            end
            
            [A(i,:),phi(i,:)]=tsaps_amplitude_phase(U1(i,:),U2(i,:));
                
            [stdev(i,1),diff(i,:)] =tsaps_signal_std(ph_mm(i,:),models(i,:));
            
            snr_ps(i,1)=snr(ph_mm(i,:),diff(i,:));
            
            if mod(i,100)==0
                fprintf(strcat(num2str(i),' PS processed\n'))
            end
        end
        
        toc
        model_parameters=[ref_ps lonlat m q stdev snr_ps];
            
        for i=1:nf
            pp=3*i-2+7;
            qq=3*i-1+7;
            rr=3*i+7;
            model_parameters(:,pp)=f(:,i);
            model_parameters(:,qq)=A(:,i);
            model_parameters(:,rr)=phi(:,i);
        end
                    
        fprintf('Unknown Frequencies Analysis: Saving Models\n')
        
        save('unknown_frequencies.mat','models','regression_lines','sinusoids','data','model_parameters','ph_mm');
        writematrix('model_parameters','unknown_frequencies_model_parameters.csv');
        writematrix('model_parameters','unknown_frequencies_models.csv');
    
        fprintf('Unknown Frequencies Analysis: Finish!\n')
        
    end


end