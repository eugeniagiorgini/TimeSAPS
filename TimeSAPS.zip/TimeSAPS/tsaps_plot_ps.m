function tsaps_plot_ps(analysis_type,ps_num)

%% TimeSAPS Plot Output - Time Series Analysis for Persistent Scatterers
% A tool for plotting the output of the TimeSAPS analysis
%
%   TimeSAPS reference: https://github.com/eugeniagiorgini/TimeSAPS
%
%   StaMPS reference: https://homepages.see.leeds.ac.uk/~earahoo/stamps/
%   
%   Train reference: https://github.com/dbekaert/TRAIN
%
% Hot to use: 
%   tsaps_plot(analysis_type,var_plot,n)
%       - Analysis_type: 'kp', 'uf'
%       - Var plot: 'm','q','std','snr','f,'A','phi'
%       - n: Relative number for f, A, phi, default is 1
%   Example: tsaps_plot('kp',A,1)
%   Example: tsaps_plot('kp',q)
%       
% <Eugenia.giorgini@unibo.it>

    %% Insert path
    prompt = "TSASP Working path: ";
    path_tsaps= input(prompt,"s")

    cd (path_tsaps)

    %% Check input argument
    if nargin<2
        error('Error: Insert the right number of inputs.')
    elseif nargin>2
        error('Error: Insert the right number of inputs.')
    else
        if strcmp(analysis_type,'uf') || strcmp(analysis_type,'kp')
            switch analysis_type
                case{'kp'}
                    load('tsaps_known_periods.mat')
                case{'uf'}
                    load('unknown_frequencies.mat')
            end 
            find_ps=find (model_parameters(:,1)==ps_num);
            checkfind=nonzeros(find_ps);
            if isempty(checkfind)
                error('Error: No PS corresponds to the code!')
            end


        else
            error('Error: The analysis must be kp or uf!')
        end
    end

    %% Var Check
    var_check=["data" "model_parameters" "models" "regression_lines" "sinusoids"];
    for i=1:length(var_check)
        if exist(var_check(i),'var')
        else
            error('Error: Some variables are missing! Load the StaMPS output. \n Variables needed: lonlat, ph_disp, ph_mm, ref_ps,day')
        end
    end

    %% Plot PS Time Series
    PS_code=find(model_parameters(:,1)==ps_num);

    figure
    plot(data,ph_mm(PS_code,:),'.','MarkerSize',10)
    hold on
    plot(data,regression_lines(PS_code,:),'.','MarkerSize',5)
    hold on
    plot(data,models(PS_code,:),'.','MarkerSize',10)
    legend('Original series','Regression Line','Model')
    title(strcat({'PS n.'},num2str(ps_num)))
    xlabel('Period [y]')
    ylabel('Displacement [mm]')

    fprintf(strcat('PS: ',num2str(model_parameters(PS_code,1)),'\n'))
    fprintf(strcat('lon: ',num2str(model_parameters(PS_code,2)),'\n'))
    fprintf(strcat('lat: ',num2str(model_parameters(PS_code,3)),'\n'))
    fprintf(strcat('m: ',num2str(model_parameters(PS_code,4)),' mm/yr \n'))
    fprintf(strcat('q: ',num2str(model_parameters(PS_code,5)),' mm \n'))
    fprintf(strcat('stdev: ',num2str(model_parameters(PS_code,6)),' mm\n'))
    fprintf(strcat('snr: ',num2str(model_parameters(PS_code,7)),'\n'))

    for i=1:(length(model_parameters(1,:))-7)/3
        pp=3*i-2+7;
        qq=3*i-1+7;
        rr=3*i+7;
        fprintf(strcat('f ',num2str(i),': ',num2str(model_parameters(PS_code,pp)),' 1/yr \t'))
        fprintf(strcat('A ',num2str(i),': ',num2str(model_parameters(PS_code,qq)),' mm \t'))
        fprintf(strcat('phi ',num2str(i),': ',num2str(model_parameters(PS_code,rr)),' rad \n'))
    end
    
    switch analysis_type
        case{'uf'}             
    
            [~,pxx_orig,~,f1,~]=tsaps_ls(ph_mm(PS_code,:),data,1);
    
            figure
            plot(f1,pxx_orig,'LineWidth',2)
            title(strcat('Periodogram PS n. ',num2str(ps_num)))
            xlabel('Frequency [1/yr]')
            ylabel('LS Power [-]')
    
    end
end
    
