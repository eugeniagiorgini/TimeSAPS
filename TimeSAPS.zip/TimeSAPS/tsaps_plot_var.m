function [plot_var,plot_title,plot_lable] =tsaps_plot_var(value,parameters,n)
    switch(value)
        case{'m'}
            plot_var=parameters(:,4);
            plot_title='m';
            plot_lable='[mm/y]';
        case{'q'}
            plot_var=parameters(:,5);
            plot_title='q';
            plot_lable='[mm]';
        case{'stdev'}
            plot_var=parameters(:,6);
            plot_title='stdev';
            plot_lable='[mm/y]';
        case{'SNR'}
            plot_var=parameters(:,7);
            plot_title='SNR';
            plot_lable='[-]';
        case{'f'}
            index=5+n*3;
            plot_var=parameters(:,index);
            plot_title=strcat({'Frequency '},num2str(n));
            plot_lable='[1/y]';       
        case{'A'}
            index=6+n*3;
            plot_var=parameters(:,index);
            plot_title=strcat({'Amplitude '},num2str(n));
            plot_lable='[mm]';
        case{'phi'}
            index=7+n*3;
            plot_var=parameters(:,index);
            plot_title=strcat({'Phase '},num2str(n));
            plot_lable='[rad]';
    end
end
