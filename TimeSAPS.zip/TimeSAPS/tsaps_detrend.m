%% TSAPS_Freq_known
% function [m,q] =TSAPS_Freq_known(t,l,t_rif)
% m,q: Regression line parameters
% t: time vector [y]
% l: time series
% t_rif: reference time for evaluating the regression line [y]


function [m,q,serie_det]=tsaps_detrend(t,l,t_rif)

    %Design matrix
    A=zeros(length(t),2);   
    for i=1:length(t)
        A(i,1)=t(i)-t_rif;
        A(i,2)=1;
    end

    x=inv(A'*A)*(A'*l);
    m=x(1,1);
    q=x(2,1);
    
    for i=1:length(t)
        serie_det(1,i)=l(i)-m*(t(i)-t(1))-q;
    end

end

