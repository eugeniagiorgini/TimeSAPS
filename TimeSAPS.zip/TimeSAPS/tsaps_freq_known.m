%% TSAPS_Freq_known
function [m,q,A1,A2] =tsaps_freq_known(t,l,t_rif,nf,f)
    A1=zeros(1,nf);
    A2=zeros(1,nf);

% Preparo matrice disegno
    A=zeros(length(t),(2+2*nf));
    
% Scrivo la matrice disegno
    for i=1:length(t)
        A(i,1)=t(i)-t_rif;
        A(i,2)=1;
    end
   
    for j=1:nf
        for i=1:length(t)
            A(i,(2+j*2-1))=sin(2*pi*f(j)*t(i));
            A(i,(2+j*2))=cos(2*pi*f(j)*t(i));
        end
    end


    x=inv(A'*A)*(A'*l);
    m=x(1,1);
    q=x(2,1);
    
    for i=1:nf
        A1(i)=x(2+i*2-1,1);
        A2(i)=x(2+i*2,1);
    end


end

