
function [Atot,phi] =tsaps_amplitude_phase(A1,A2)

    for i=1:length(A1(1,:))
        Atot(1,i)=sqrt(A1(i)^2+A2(i)^2);
        phi(1,i)=atan2(-A1(i),A2(i));
    end

end

