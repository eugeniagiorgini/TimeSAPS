function [freq_known,N_freq_known] = tsaps_freq_conversion(periods)

    k=1;
    for i=1:length(periods)
    
    if periods(i) ~= 0
        freq_known(k)=1/periods(i);
        k=k+1;
    end

    N_freq_known=k-1;
    
end

