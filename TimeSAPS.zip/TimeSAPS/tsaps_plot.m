function tsaps_plot(analysis_type,var_plot,n)

%% TimeSAPS Plot Output - Time Series Analysis for Persistent Scatterers
% A tool for plotting the output of the TimeSAPS analysis
%
%   TimeSAPS reference: https://github.com/eugeniagiorgini/TimeSAPS
%
%   StaMPS reference: https://homepages.see.leeds.ac.uk/~earahoo/stamps/
%   
%   Train reference: https://github.com/dbekaert/TRAIN
%
% Hot to use: 
%   tsaps_plot(analysis_type,var_plot,n)
%       - Analysis_type: 'kp', 'uf'
%       - Var plot: 'm','q','std','snr','f,'A','phi'
%       - n: Relative number for f, A, phi, default is 1
%   Example: tsaps_plot('kp',A,1)
%   Example: tsaps_plot('kp',q)
%       
% <Eugenia.giorgini@unibo.it>

%% Insert path
prompt = "TSASP Working path: ";
path_tsaps= input(prompt,"s")

cd (path_tsaps)

%% Check input argument
if nargin<2
    error('Error: Insert the right number of inputs.')
elseif nargin>3
    error('Error: Insert the right number of inputs.')
else
    if strcmp(analysis_type,'uf') || strcmp(analysis_type,'kp')
        if strcmp(var_plot,'m') || strcmp(var_plot,'q') || strcmp(var_plot,'std') || strcmp(var_plot,'snr') || strcmp(var_plot,'f') || strcmp(var_plot,'A') || strcmp(var_plot,'phi')   
        else
            error('Error: The variable plot must be m, q, std, snr, f, A, phi!')
        end
        
    else
        error('Error: The analysis must be kp or uf!')
    end
    if nargin==2
        n=1;
    else
        switch analysis_type
            case{'kp'}
                load('tsaps_known_periods.mat')
            case{'uf'}
                load('unknown_frequencies.mat')
        end    
        if n<0
            error('Error: n must be positive!')
        elseif (length(model_parameters(1,:))-7)/3<n
            error('Error: n must be maximum number of frequencies searched!')
        end
    end
end

    
    
    
%% Load data
var_check=["data" "model_parameters" "models" "regression_lines" "sinusoids"];
for i=1:length(var_check)
    if exist(var_check(i),'var')
    else
        error('Error: Some variables are missing! Load the StaMPS output. \n Variables needed: lonlat, ph_disp, ph_mm, ref_ps,day')
    end
end


%% Plot 

[plot_var,plot_title,plot_lable] = tsaps_plot_var(var_plot,model_parameters,n);
plot_var=double(plot_var);

if strcmp(var_plot,'m')|| strcmp(var_plot,'q')|| strcmp(var_plot,'stdev')|| strcmp(var_plot,'SNR')
    figure
    fig_scatter=geoscatter(model_parameters(:,3),model_parameters(:,2),plot_var,'filled');
    title(plot_title)
    cbar_fig_scatter=colorbar;
    cbar_fig_scatter.Label.String=plot_lable;
    ps_row=dataTipTextRow('PS',double(model_parameters(:,1)));
    fig_scatter.DataTipTemplate.DataTipRows(end+1) = ps_row;
    ps_row_2=dataTipTextRow("Value",plot_var,'%.2f');
    fig_scatter.DataTipTemplate.DataTipRows(end+1) = ps_row_2;
else
    k=1;
    for i=1:length(plot_var)
        if (plot_var(i)~=0)
            model_parameters_nozeros(k,:)=model_parameters(i,:);
            plot_var_nonzeros(k)=plot_var(i);
            k=k+1;
        end
    end
    figure
    fig_scatter=geoscatter(model_parameters(:,3),model_parameters(:,2),10,'k','filled');
    title(plot_title)
    
    hold on
    fig_scatter=geoscatter(model_parameters_nozeros(:,3),model_parameters_nozeros(:,2),20,plot_var_nonzeros,'filled');
    cbar_fig_scatter=colorbar;
    cbar_fig_scatter.Label.String=plot_lable;
    ps_row=dataTipTextRow('PS',double(model_parameters_nozeros(:,1)));
    fig_scatter.DataTipTemplate.DataTipRows(end+1) = ps_row;
    ps_row_2=dataTipTextRow("Value",plot_var_nonzeros,'%.2f');
    fig_scatter.DataTipTemplate.DataTipRows(end+1) = ps_row_2;

end 
