function [segnali,retta,finale] =tsaps_signal_recostruction(time,m,q,nf,f,A1,A2)

    segnali_singoli=zeros(nf,length(time));
    segnali=zeros(1,length(time));
    retta=zeros(1,length(time));
    finale=zeros(1,length(time));
    
    for p=1:nf
        segnali_singoli(p,:)=A1(1,p)*sin(time'.*(2*pi*f(1,p)))+A2(1,p)*cos(time'.*(2*pi*f(1,p))); 
        segnali(1,:)=segnali(1,:)+segnali_singoli(p,:);
    end
    for kk=1:length(time)
        retta(1,kk)=q+m*(time(kk)-time(1));
    end

    finale(1,:)=segnali(1,:)+retta(1,:);
end
