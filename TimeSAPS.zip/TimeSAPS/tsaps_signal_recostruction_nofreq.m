function [retta,finale] =tsaps_signal_recostruction_nofreq(time,m,q)

    retta=zeros(length(m),length(time));
    finale=zeros(length(m),length(time));

    for kk=1:length(time)
        retta(1,kk)=q(1)+m(1)*(time(kk)-time(1));
    end

    finale(1,:)=retta(1,:);
end
