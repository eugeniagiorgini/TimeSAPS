function [m,q,A1,A2,f_out,signals,line,model] = tsaps_find_signals(nf,ph_mm_det,ph_mm,time)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    m=0;
    q=0;
    A1=zeros(1,nf);
    A2=zeros(1,nf);
    f_out=zeros(1,nf);
    signals=zeros(1,length(time));
    line=zeros(1,length(time));
    model=zeros(1,length(time));
    for j=1:nf

        [f_out_temp,~,~,~,~]=tsaps_ls(ph_mm_det',time,1);
        f_out(1,j)=f_out_temp(1);
        if f_out_temp(1) == 0
            break
        else
            f_out_ok=nonzeros(f_out(1,:))';
            n_f_out_ok=(length(f_out_ok));
            
            [m,q,A1,A2] = tsaps_freq_known(time,ph_mm',time(1),n_f_out_ok,f_out_ok);
            
            [signals,line,model] =tsaps_signal_recostruction(time,m,q,n_f_out_ok,f_out_ok,A1,A2);

            ph_mm_det=ph_mm-model(1,:);
            
            if n_f_out_ok<nf
                f_out_ok([n_f_out_ok+1:nf])=0;
                A1([n_f_out_ok+1:nf])=0;
                A2([n_f_out_ok+1:nf])=0;
            end
            
        end
    end
end

