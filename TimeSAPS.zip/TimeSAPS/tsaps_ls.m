function [f_out,pxx_orig,pxx,f1,pxx_mod]=tsaps_ls(x,t,nf)

%%% DETREND a PRIORI o comunque da fare

% ANALISI SEGNALE 
%   Funzione per l'analisi del segnale di una serie temporale. 
%   Viene eseguita l'analisi nel dominio delle frequenze mediante il 
%   periodogramma di Lomb Scagle e successivamente, una volta stimata la
%   frequenza più potente, si calcolando le ampiezze associate mediante un
%   approccio ai minimi quadrati. La procedura viene reiterata in base a
%   quante frequenze si sceglie di indagare.
%   Equazione di riferimento:
%   S=Σ[A1*sin(2*pi*f*t)+A2*cos(2*pi*f*t)]
%   con: S segnale, f frequenza, A1 e A2 ampiezze, t tempo
%
%   [x_deon,f,A1,A2] = analisi_segnale(x,t,nf) 
%   con:
%   x vettore della serie da analizzare
%   t vettore tempo associato alla serie
%   nf numero di frequenze che si vogliono indagare (nelle serie giornaliere GNSS non più di 5)
%   x_deon vettore serie data dalla sottrazione del segnale alla serie originale
%   f vetttore contenente i valori della frequenze trovate
%   A1,A2 vetttore contenente i valori della ampiezze trovate
%
%   IMPORTANTE: per funzionare, la funzione necessita della function 
%   matlab plomb 
%
%   Copyright 2018 Luca Poluzzi luca.poluzzi5@unibo.it

    model_final=zeros(length(t));
        
    %% calcolo frequenza con Lomb Scargle
    	fmax=12; 
    	ofac=round(60000*24/length(t));
        Pfa = [50 10 1 0.01]/100;
        Pd = 1-Pfa;
        % periodogramma
        [pxx,f1,pth]=plomb(x,t,fmax,ofac,'normalized','Pd',Pd);
        pxx_orig=pxx;
        pxx_mod=pxx;
        % picco periodogramma -  a noi servono i primi nf.
        [~,idx]=max(pxx);
        
        for i=1:nf
            [~,idx]=max(pxx);
            % frequenza relativa al picco
            if pxx(idx)>pth(3)              %%%EUGI->cacchio è pth(4)?
                f_out(i,1)=f1(idx);
                upper=length(pxx)-idx;
                lower=length(pxx)-upper-1;
                stop=0;
                for k=1:min(upper,lower)
                    if ((pxx(idx+k)<=pxx(idx+k-1))&&(pxx(idx-k)<=pxx(idx-k+1)))
                        stop=stop+1;
                    else
                        pxx(idx-stop:idx+stop)=0;
                        break;
                    end
                end
                minpos=k-lower;
                if minpos==0
                    for k=(lower+1):upper
                        if ((pxx(idx+k)<pxx(idx+k-1)))
                            stop=stop+1;
                        else
                            pxx(1:idx+stop)=0;
                            break;
                        end
                    end
                else
                    pxx(idx-stop:idx+stop)=0;
                end     
                
            else
                f_out(i,1)=0;
            end
            pxx_mod(:,i+1)=pxx(:);
            %pxx(idx)=[];
            %f1(idx)=[];  
            
%             figure
%             plot(f1,pxx_orig,'LineWidth',3)
%             hold on
%             plot(f1,pxx,'LineWidth',2)
            
            
        end            

end
