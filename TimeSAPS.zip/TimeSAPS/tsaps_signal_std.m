function [stdev,diff] =tsaps_signal_std(serie,finale)
    diff=serie-finale;

    stdev=std(diff);
end
